<?php				

	include 'koneksi.php';

		$no = 1;

		$number = mysqli_query($dbconnect, "SELECT * FROM data_barang");



		while ($query = mysqli_fetch_assoc($number)) {

?>