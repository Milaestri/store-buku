<?php

   include 'koneksi.php';


 $judul_buku= $_POST['judul_buku'];
 $penerbit_buku= $_POST['penerbit_buku'];
 $genre_buku= $_POST['genre_buku'];
 $tanggal_pembelian= $_POST['tanggal_pembelian'];
 






  mysqli_query($dbconnect, "INSERT INTO data_barang VALUES (NULL,'$judul_buku','$penerbit_buku','$genre_buku','$tanggal_pembelian')");

  header("location:index.php");

  ?>