<?php
include 'koneksi.php';

$nama = $_POST['nama'];
$email = $_POST['email'];
$password = $_POST['password'];

mysqli_query($dbconnect, "INSERT INTO data_barang ( `nama`,`email`, `password`) VALUES (NULL, '$nama', '$email', '$password');");

header('location:login.php');
?>