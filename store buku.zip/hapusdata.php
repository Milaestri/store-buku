<?php 
include 'koneksi.php';
$nama=$_GET['nama'];

mysqli_query($dbconnect, "DELETE FROM data_barang WHERE nama = '$nama'");

header('location:index.php');

