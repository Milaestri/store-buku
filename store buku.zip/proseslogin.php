<?php
include 'koneksi.php';
$email = $_POST["email"];
$password = $_POST["password"];

$query_sql = "SELECT * FROM `data_barang` WHERE email = '$email' AND password = '$password'";

$result = mysqli_query($dbconnect, $query_sql);

if(mysqli_query($dbconnect, $query_sql) > 0){
	    echo "<h1>Selamat Anda Berhasil Melakukan Login</h1>";
	    header("location:index.php");
}else{
	echo '<script type="text/JavaScript">';
	echo 'alert("Mohon Maaf Username Atau Password Yang Anda Masukkan Salah")';
	echo '</script>';
	 

}
?>
