  <!DOCTYPE HTML>
<html>
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Store Book</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">

  	<!-- Facebook and Twitter integration -->
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />

	<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700" rel="stylesheet">
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Themify Icons-->
	<link rel="stylesheet" href="css/themify-icons.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">

	<!-- Magnific Popup -->
	<link rel="stylesheet" href="css/magnific-popup.css">

	<!-- Magnific Popup -->
	<link rel="stylesheet" href="css/bootstrap-datepicker.min.css">

	<!-- Owl Carousel  -->
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">

	<!-- Theme style  -->
	<link rel="stylesheet" href="css/style.css">

	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->

	</head>
	<body>
		
	<div class="gtco-loader"></div>
	
	<div id="page">

	
	<!-- <div class="page-inner"> -->
	<nav class="gtco-nav" role="navigation">
		<div class="gtco-container">
			
			<div class="row">
				<div class="col-sm-4 col-xs-12">
					<div id="gtco-logo"><a href="index.php"> Store Book <em></em></a></div>
				</div>
				<div class="col-xs-8 text-right menu-1">
					<ul>
						<li><a href="index.php">Home</a></li>
						<li class="has-dropdown">
							<a href="#">Data Buku</a>
							<ul class="dropdown">
								<li><a href="#">Novel</a></li>
								<li><a href="#">Komik</a></li>
								<li><a href="#">Cerita Rakyat</a></li>
								<li><a href="#">Majalah</a></li>
							</ul>
						</li>
						<li><a href="login.php">Logout</a></li>
						<li><a href="contact.php">Contact</a></li>
					</ul>	
				</div>
			</div>
			
		</div>
	</nav>
	
	<header id="gtco-header" class="gtco-cover gtco-cover-md" role="banner" style="background-image: url(images/img_bg_2.jpg)">
		<div class="overlay"></div>
		<div class="gtco-container">
	
			<div class="row">
				<div class="col-md-12 col-md-offset-0 text-left">
					

					<div class="row row-mt-15em">
						<div class="col-md-7 mt-text animate-box" data-animate-effect="fadeInUp">
							<h1>Never trust anyone who doesn't carry a book.</h1>	
						</div>
						<div class="col-md-4 col-md-push-1 animate-box" data-animate-effect="fadeInRight">
							<div class="form-wrap">
								<div class="tab">
									
									<div class="tab-content">
										<div class="tab-content-inner active" data-content="signup">
											<h3>Book Your Trip</h3>
											<form action="prosesinputdata.php" method="post">
												<div class="row form-group">
													<div class="col-md-12">
														<label for="fullname">Judul Buku</label>
														<input type="text" name="judul" id="fulljudul" class="form-control">
													</div>
												</div>
												<div class="row form-group">
													<div class="col-md-12">
														<label for="validationServer04">Penerbit Buku</label>
														<select name="penerbit" id="validationServer04" class="form-control">
															<option value="">Choose</option>
															<option>Magarett Nense</option>
															<option>Rupi kaur</option>
															<option>Nukita Gill</option>
															<option>Alex Lemon</option>
															<option>Bonita</option>
														</select>
													</div>
												</div>

												<div class="row form-group">
													<div class="col-md-12">
														<label for="genre_buku">Genre Buku</label>
														<input type="text" name="genre"id="genre" class="form-control">
														
													</div>
												</div>
												
												<div class="row form-group">
													<div class="col-md-12">
														<label for="image">Image</label>
														<input type="file" name="image"id="image" class="form-control">
														
													</div>
												</div>

												<div class="row form-group">
													<div class="col-md-12">
														<label for="tanggal_pembelian">Tanggal Pembelian</label>
														<input type="text" name="time" id="date-start" class="form-control">
													</div>
												</div>

												<div class="row form-group">
													<div class="col-md-12"><button class="btn btn-primary">SEND</button>
														
													</div>
												</div>
											</form>	
										</div>

										
									</div>
								</div>
							</div>
						</div>
					</div>
							
					
				</div>
			</div>
		</div>
	</header>
	
	<div class="gtco-section">
		<div class="gtco-container">
			<div class="row">
				<div class="col-md-8 col-md-offset-2 text-center gtco-heading">
					<h2>Interesting And Updated Book</h2>
					<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempore eos molestias quod sint ipsum possimus temporibus officia iste perspiciatis consectetur in fugiat repudiandae cum.</p>
				</div>
			</div>


	
		
		<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
		<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
			<h1 class="h2">Input Data Barang</h1>
		</div>


<section>
	
	<form action="prosesinputbarang.php" method="post">
		
		<div class="mb-3">
			
			<label for="kodebarang" class="form-label">Kode_Barang</label>

			<input type="text" class="form-control" name="kodebarang" id="kodebarang" autocomplete="off" required placeholder="Masukkan Kode Barang">
				
		</div>

		<div class="mb-3">
			
			<label for="namabarang" class="form-label">Nama_Barang</label>

			<input type="text" name="namabarang" class="form-control" id="namabarang" placeholder="Masukkan Nama Barang" required autocomplete="off">
		</div>

		<div class="mb-3">

			<label for="harga" class="form-label">Harga</label>

			<input type="text" name="harga" class="form-control" id="harga" placeholder="Masukkan Harga" required autocomplete="off">

		</div>

		<div class="mb-3">

			<label for="stok" class="form-label">Stok</label>

			<input type="number" name="stok" class="form-control" id="stok" required autocomplete="off">

		</div>

		<div class="mb-3">
			
			<label for="supplier" class="form-label">Supplier</label>

			<input type="text" name="supplier" class="form-control" id="supplier" required autocomplete="off">

		</div>


		 <button type="submit" name="inputdata" class="btn btn-primary" onclick="return confirm ('Apa kamu yakin ingin menghapus akun mu? data tidak dapat diubah setelah data dikirim')">Input Data</button>

			</label>
		</div>
	</form>
</section>
	  </main>
	</div>
  </div>
		

 	
		<script type="text/javascript" src="../assets/js/bootstrap.bundle.min.js"></script>

		<script src="https://cdn.jsdelivr.net/npm/feather-icons@4.28.0/dist/feather.min.js" integrity="sha384-uO3SXW5IuS1ZpFPKugNNWqTZRRglnUJK6UAZ/gxOX80nxEkN9NcGZTftn6RzhGWE" crossorigin="anonymous"></script><script src="https://cdn.jsdelivr.net/npm/chart.js@2.9.4/dist/Chart.min.js" integrity="sha384-zNy6FEbO50N+Cg5wap8IKA4M/ZnLJgzc6w2NqACZaK0u0FXfOWRRJOnQtpZun8ha" crossorigin="anonymous"></script><script src="dashboard.js"></script>
		<footer>
            <div class="container">
        <small><center>Copyright &copy; 2022 - Mila/17/XI RPL2</center></small>        
            </div>
        </footer>
 	</body>
 </html>


<table id="example1" class="table table-responsive-x1 table-hover display">
			
			<thead>
				
				<tr>
					
					<th>id</th>

					<th>Kode Barang</th>

					<th>Nama Barang</th>

					<th>Harga</th>

					<th>Stok</th>

					<th>Supplier</th>

					<th>aksi</th>

				</tr>

			</thead>

			<tbody>
				
<?php				

	include 'koneksi.php';

		$no = 1;

		$number = mysqli_query($dbconnect, "SELECT * FROM barang");



		while ($query = mysqli_fetch_assoc($number)) {

?>
	
	<form  action="" method="post">
		
		   <tr>
		   	
		   	 <td><?php echo $no++;  ?></td>

		   	 <td><?php echo $query ['kode_barang']  ?></td>

		   	 <td><?php echo $query ['nama_barang']  ?></td>

		   	 <td><?php echo $query ['harga'] ?></td>

		   	 <td><?php echo $query ['stok']  ?></td>

		   	 <td><?php echo $query ['supplier']  ?></td>

		   	 <td>
		   	 	
		   	 	<a href="updatedata.php?id=<?php echo $query ['id']?>" class="btn btn-primary">Edit</a>

		   	 	<a href="proseshapusdata.php?id=<?php echo $query ['id']?>" class="btn btn-danger" onclick="return confirm ('Opo sampeyan yakin arep mbusak akun mu?? dengan id <?php echo $query ['id']?>??')">Hapus</a>
		   	 </td>
		   </tr>




	
		
	



	<div class="gtco-cover gtco-cover-sm" style="background-image: url(images/img_bg_1.jpg)"  data-stellar-background-ratio="0.5">
		<div class="overlay"></div>
		<div class="gtco-container text-center">
			<div class="display-t">
				<div class="display-tc">
					<h1>We have a wide range of affordable books that you're sure to love!</h1>
				</div>	
			</div>
		</div>
	</div>

	<div id="gtco-counter" class="gtco-section">
		<div class="gtco-container">

			<div class="row">
				<div class="col-md-8 col-md-offset-2 text-center gtco-heading animate-box">
					<h2>Our Selling Data</h2>
					<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempore eos molestias quod sint ipsum possimus temporibus officia iste perspiciatis consectetur in fugiat repudiandae cum.</p>
				</div>
			</div>

			<div class="row">
				
				<div class="col-md-3 col-sm-6 animate-box" data-animate-effect="fadeInUp">
					<div class="feature-center">
						<span class="counter js-counter" data-from="0" data-to="484" data-speed="5000" data-refresh-interval="50">1</span>
						<span class="counter-label">Novel</span>

					</div>
				</div>
				<div class="col-md-3 col-sm-6 animate-box" data-animate-effect="fadeInUp">
					<div class="feature-center">
						<span class="counter js-counter" data-from="0" data-to="397" data-speed="5000" data-refresh-interval="50">1</span>
						<span class="counter-label">Komik</span>
					</div>
				</div>
				<div class="col-md-3 col-sm-6 animate-box" data-animate-effect="fadeInUp">
					<div class="feature-center">
						<span class="counter js-counter" data-from="0" data-to="92239" data-speed="5000" data-refresh-interval="50">1</span>
						<span class="counter-label">Cerita Rakyat</span>
					</div>
				</div>
				<div class="col-md-3 col-sm-6 animate-box" data-animate-effect="fadeInUp">
					<div class="feature-center">
						<span class="counter js-counter" data-from="0" data-to="45327" data-speed="5000" data-refresh-interval="50">1</span>
						<span class="counter-label">Majalah</span>

					</div>
				</div>
					
			</div>
		</div>
	</div>

	<footer id="gtco-footer" role="contentinfo">
		<div class="gtco-container">
			<div class="row row-p	b-md">

				<div class="col-md-4">
					<div class="gtco-widget">
						<h3>About Us</h3>
						<p>The best shop to get the books you want</p>
					</div>
				</div>

				<div class="col-md-3 col-md-push-1">
					<div class="gtco-widget">
						<h3>Contact Us</h3>
						<ul class="gtco-quick-contact">
							<li><a href="#"><i class="icon-phone"></i>083806713590</a></li>
							<li><a href="#"><i class="icon-mail2"></i>kelompok6@gmail.com</a></li>
							<li><a href="#"><i class="icon-chat"></i> Live Chat</a></li>
						</ul>
					</div>
				</div>

			</div>

			<div class="row copyright">
				<div class="col-md-12">
					<p class="pull-left">
						<small class="block">&copy; Kelompok 6. All Rights Reserved.</small> 
					</p>
					<p class="pull-right">
						<ul class="gtco-social-icons pull-right">
							<li><a href="#"><i class="icon-twitter"></i></a></li>
							<li><a href="#"><i class="icon-facebook"></i></a></li>
							<li><a href="#"><i class="icon-linkedin"></i></a></li>
							<li><a href="#"><i class="icon-dribbble"></i></a></li>
						</ul>
					</p>
				</div>
			</div>

		</div>
	</footer>
	<!-- </div> -->

	</div>

	<div class="gototop js-top">
		<a href="#" class="js-gotop"><i class="icon-arrow-up"></i></a>
	</div>
	
	<!-- jQuery -->
	<script src="js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<!-- Carousel -->
	<script src="js/owl.carousel.min.js"></script>
	<!-- countTo -->
	<script src="js/jquery.countTo.js"></script>

	<!-- Stellar Parallax -->
	<script src="js/jquery.stellar.min.js"></script>

	<!-- Magnific Popup -->
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/magnific-popup-options.js"></script>
	
	<!-- Datepicker -->
	<script src="js/bootstrap-datepicker.min.js"></script>
	

	<!-- Main -->
	<script src="js/main.js"></script>

	</body>
</html>

 </html>