<?php
   include 'koneksi.php';
 $judul_buku= $_POST['judul_buku'];
 $penerbit_buku= $_POST['penerbit_buku'];
 $genre_buku= $_POST['genre_buku'];
 $tanggal_pembelian= $_POST['tanggal_pembelian'];






  mysqli_query($dbconnect, "UPDATE `data_barang` SET `judul_buku`='$judul_buku',`penerbit_buku`='$penerbit_buku',`genre_buku`='$genre_buku',`tanggal_pembelian`='$tanggal_pembelian' ");

  header("location:index.php");
  ?>


