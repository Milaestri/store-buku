<?php

$host = "localhost";
$user = "root";
$pass = "";
$db   = "store buku";

$dbconnect = new mysqli("$host","$user","$pass","$db");





?>