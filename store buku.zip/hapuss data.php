  <!DOCTYPE HTML>
<html>
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Store Book</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">


  	<!-- Facebook and Twitter integration -->
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />

	<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700" rel="stylesheet">
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Themify Icons-->
	<link rel="stylesheet" href="css/themify-icons.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">

	<!-- Magnific Popup -->
	<link rel="stylesheet" href="css/magnific-popup.css">

	<!-- Magnific Popup -->
	<link rel="stylesheet" href="css/bootstrap-datepicker.min.css">

	<!-- Owl Carousel  -->
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">

	<!-- Theme style  -->
	<link rel="stylesheet" href="css/style.css">

	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->

	</head>
	<body>
		
	<div class="gtco-loader"></div>
	
	<div id="page">

	
	<!-- <div class="page-inner"> -->

		<?php

    include 'koneksi.php';

      $no = 1;

         $number = mysqli_query($dbconnect, "SELECT * FROM data_barang");


    while ($query = mysqli_fetch_assoc($number)) {
      
?>

	<nav class="gtco-nav" role="navigation">
		<div class="gtco-container">
			
			<div class="row">
				<div class="col-sm-4 col-xs-12">
					<div id="gtco-logo"><a href="index.php"> 	Store Book <em>.</em></a></div>
				</div>
				<div class="col-xs-8 text-right menu-1">
					<ul>
						<li><a href="index.php">Home</a></li>
						<li class="has-dropdown">
							<a href="#">Data Buku</a>
							<ul class="dropdown">
								<li><a href="#">Novel</a></li>
								<li><a href="#">Komik</a></li>
								<li><a href="#">Cerita Rakyat</a></li>
								<li><a href="#">Majalah</a></li>
							</ul>
						</li>
						<li><a href="login.php">Login</a></li>
						<li><a href="contact.php">Contact</a></li>
					</ul>	
				</div>
			</div>
			
		</div>
	</nav>
	
	<header id="gtco-header" class="gtco-cover gtco-cover-md" role="banner" style="background-image: url(images/img_bg_2.jpg)">
		<div class="overlay"></div>
		<div class="gtco-container">
	
			<div class="row">
				<div class="col-md-12 col-md-offset-0 text-left">
					

					<div class="row row-mt-15em">
						<div class="col-md-7 mt-text animate-box" data-animate-effect="fadeInUp">
							<h1>What Book Are You Planning To Buy?</h1>	
						</div>
						<div class="col-md-4 col-md-push-1 animate-box" data-animate-effect="fadeInRight">
							<div class="form-wrap">
								<div class="tab">
									
									<div class="tab-content">
										<div class="tab-content-inner active" data-content="signup">
											<h3>Book Your Trip</h3>
											<form action="prosesupdate.php" method="post">
												<div class="row form-group">
													<div class="col-md-12">
														<label for="fullname">Id</label>
														<input type="text" reandonly="" class="form-control" id="id" name="id" value="<?php echo $query ['id']?>">
													</div>
												</div>

												<div class="row form-group">
													<div class="col-md-12">
														<label for="fulljudul">Judul Buku</label>
														 <label for="judul" class="form-label">Judul</label>
        												<input type="text" class="form-control" id="judul" name="judul" required autocomplete="off" value="<?php echo $query ['judul']?>">
													</div>
												</div>
												<div class="row form-group">
													<div class="col-md-12">
														<label for="validationServer04">Penerbit Buku</label>
														<select name="penerbit" id="validationServer04" class="form-control">
															<option value="">Choose</option>
															<option>Magarett Nense</option>
															<option>Rupi kaur</option>
															<option>Nukita Gill</option>
															<option>Alex Lemon</option>
															<option>Bonita</option>
														</select>
													</div>
												</div>
												<div class="row form-group">
													<div class="col-md-12">
														<label for="genre">Genre Buku</label>
        											<input type="text" class="form-control" id="genre" name="genre" required autocomplete="off" value="<?php echo $query ['genre']?>">
														
													</div>
												</div>

												<div class="row form-group">
													<div class="col-md-12">
														<label for="Image">Image</label>
														<input type="file" name="Image" class="form-control">
														
													</div>
												</div>
												
												<div class="row form-group">
													<div class="col-md-12">
														<label for="testDate">Tanggal Pembelian</label>
														<input type="text" class="form-control" id="date-start" name="time" required autocomplete="off" value="<?php echo $query ['time']?>">
													</div>
												</div>

												<div class="row form-group">
													<div class="col-md-12"><button class="btn btn-primary">Hapus</button>
														
													</div>
												</div>
											</form>	
										</div>

										
									</div>
								</div>
							</div>
						</div>
					</div>
							
					
				</div>
			</div>
		</div>
	</header>
	<?php
}
?>

	<div class="gototop js-top">
		<a href="#" class="js-gotop"><i class="icon-arrow-up"></i></a>
	</div>
	
	<!-- jQuery -->
	<script src="js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<!-- Carousel -->
	<script src="js/owl.carousel.min.js"></script>
	<!-- countTo -->
	<script src="js/jquery.countTo.js"></script>

	<!-- Stellar Parallax -->
	<script src="js/jquery.stellar.min.js"></script>

	<!-- Magnific Popup -->
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/magnific-popup-options.js"></script>
	
	<!-- Datepicker -->
	<script src="js/bootstrap-datepicker.min.js"></script>
	

	<!-- Main -->
	<script src="js/main.js"></script>

	</body>
</html>

